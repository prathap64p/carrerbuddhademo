package com.interview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class RecyclerAdapter  extends RecyclerView.Adapter<RecyclerAdapter.myViewHolder>
{

    private static final int TYPE = 1;
    private final Context context;
    private List<Root> listRecyclerItem;
    public void setData(List<Root> data) {
        this.listRecyclerItem = data;
        notifyDataSetChanged();
    }


    public RecyclerAdapter(Context context, List<Root> listRecyclerItem) {
        this.context = context;
        this.listRecyclerItem = listRecyclerItem;
    }

    @NonNull
    @Override
    public RecyclerAdapter.myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {

        switch (i) {
            case TYPE:

            default:

                View layoutView = LayoutInflater.from(parent.getContext()).inflate(
                        R.layout.recycler_custom_singlitem, parent, false);

                return new myViewHolder(layoutView);
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.myViewHolder holder, int position)
    {

        int viewType = getItemViewType(position);

        switch (viewType) {
            case TYPE:
            default:

                //Root root = (Root) listRecyclerItem.get(position);

                Root root = (Root) listRecyclerItem.get(position);
                holder.recycler_person_name.setText(root.getResults().get(position).getName().getFirst());
                holder.recycler_person_profession.setText(root.getResults().get(position).getLocation().getCity());

                Picasso.get()
                        .load(root.getResults().get(position).getPicture().getThumbnail())
                        .error(R.drawable.ic_baseline_person_24)
                        .into(holder.recycler_custom_image);


        }
    }

    @Override
    public int getItemCount() {
        return listRecyclerItem.size();
    }


    public class myViewHolder extends RecyclerView.ViewHolder
    {
        private TextView recycler_person_name;
        private TextView recycler_person_profession;
        private ImageView recycler_custom_image;


        public myViewHolder(@NonNull View itemView) {
            super(itemView);

            recycler_person_name = (TextView) itemView.findViewById(R.id.recycler_person_name);
            recycler_person_profession = (TextView) itemView.findViewById(R.id.recycler_person_profession);
            recycler_custom_image = (ImageView) itemView.findViewById(R.id.recycler_custom_image);

        }
    }
}
